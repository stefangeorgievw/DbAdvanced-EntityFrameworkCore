﻿using System;
using System.Linq;
using P02_DatabaseFirst.Data;
using P02_DatabaseFirst.Data.Models;

namespace P02_DatabaseFirst
{
    class StartUp
    {
        static void Main(string[] args)
        {
            using(var db = new SoftUniContext())
            {
                var employees = db.Employees.ToArray();

                foreach (var e in employees)
                {
                    Console.WriteLine(e.FirstName);
                }

            }
        }
    }
}
